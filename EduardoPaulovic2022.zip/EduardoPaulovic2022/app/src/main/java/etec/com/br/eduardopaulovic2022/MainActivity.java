package etec.com.br.eduardopaulovic2022;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btPesquisar, btnClear;
    EditText edttCEP;
    ListView lsttCep;
    String cep, endereco, txtRua, txtBairro, txtCidade, txtEstado;

    private List<Cep> listaCep = new ArrayList<>();
    private ArrayAdapter<Cep> adaptadorCEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btPesquisar = findViewById(R.id.btnPesquisar);
        edttCEP = findViewById(R.id.edtCep);
        lsttCep = findViewById(R.id.LstCEP);
        btnClear = findViewById(R.id.btnClear);

        adaptadorCEP = new ArrayAdapter<Cep>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                listaCep);
        lsttCep.setAdapter(adaptadorCEP);

        btPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edttCEP.getText().length() != 8){
                    edttCEP.setError("Favor informe um CEP válido!");
                }
                else{
                    cep = edttCEP.getText().toString();
                    endereco = "https://viacep.com.br/ws/"+cep+"/json/";
                    buscar(endereco);
                }
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    public void buscar(String endereco){
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest str = new StringRequest(
                Request.Method.GET, endereco,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.e("teste", response);
                        try {
                            JSONObject info = new JSONObject(response);
                            Cep valor = new Cep();
                            valor.setRua(info.getString("logradouro"));
                            valor.setBairro(info.getString("bairro"));
                            valor.setCidade(info.getString("localidade"));
                            valor.setEstado(info.getString("estado"));
                            valor.setCep(info.getString("cep"));
                            listaCep.add(valor);
                            adaptadorCEP.notifyDataSetChanged();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(str);
    }
}